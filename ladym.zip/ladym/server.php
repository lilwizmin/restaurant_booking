<?php


$conn = mysqli_connect("localhost", "root", "", "ladym");

if(!$conn){
    echo "Failed to connect";
}

?>