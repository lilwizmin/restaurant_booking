<section class="about_section layout_padding">
    <div class="container  ">

      <div class="row">
        <div class="col-md-6 ">
          <div class="img-box">
            <img src="images/about-img.png" alt="">
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
            <div class="heading_container">
              <h2>
                We Are Lady M Fast Food
              </h2>
            </div>
            <p>
              There are many variaties of food and snacks available, but the majority taste is our pride 24/7, 
              randomised all your hunger in one click we are there for you.don't look even slightly worried. If you
              are going to Reserved a table try Lady M fast foods , you need to be sure there isn't anything embarrassing hidden in
              the middle of the day. All
            </p>
            <a href="">
              Read More
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>