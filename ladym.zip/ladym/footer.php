



    <footer class="mt-3" style="position: relative; bottom: 0px; width: 100%; padding-bottom:100px;">
            <p>&copy; 2023-<?php echo date("Y"); ?> ProxyTech Digital Concept. All rights reserved.</p>
    </footer>

