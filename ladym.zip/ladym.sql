-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2023 at 07:10 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ladym`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `full_name` varchar(250) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `num_of_persons` varchar(10) NOT NULL,
  `date` varchar(100) NOT NULL,
  `r_type` varchar(100) NOT NULL,
  `food_choices` varchar(255) NOT NULL,
  `soft_drinks` varchar(100) NOT NULL,
  `payment_type` varchar(100) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `reference` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `full_name`, `phone`, `email`, `address`, `num_of_persons`, `date`, `r_type`, `food_choices`, `soft_drinks`, `payment_type`, `comments`, `reference`) VALUES
(1, 'Yusuf Ibrahim', '09876534657', 'ibrobk@yahoo.com', 'No 2', '3', '2023-10-21', 'Table serving', 'rice&salat', 'fruits juice', 'ATM card', 'dsgfdfgf', 'LadyM-6534053decf54');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category`) VALUES
(1, 'pizza'),
(2, 'chips'),
(3, 'snacks'),
(4, 'drinks');

-- --------------------------------------------------------

--
-- Table structure for table `drinks`
--

CREATE TABLE `drinks` (
  `id` int(11) NOT NULL,
  `drink_name` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `foods`
--

CREATE TABLE `foods` (
  `id` int(11) NOT NULL,
  `food_image` varchar(250) NOT NULL,
  `food_name` varchar(250) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` varchar(250) NOT NULL,
  `price` varchar(10) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `trx_type` varchar(200) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `order_name` varchar(255) NOT NULL,
  `reference` varchar(250) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `amount` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `image_url` varchar(100) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `product_name`, `category`, `quantity`, `price`, `image_url`, `created_on`, `description`) VALUES
(14, 'Patato Chips', 'chips', 0, 1200, 'f5.png', '2023-10-21 11:44:38', '\r\n          Patato chips with egg and Salad.      '),
(15, 'Hot Pizza', 'pizza', 5, 2000, 'f6.png', '2023-10-21 11:47:51', 'Hot Pizza with Spices \r\n                ');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `food_name` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `card_number` varchar(100) NOT NULL,
  `expiry_date` varchar(100) NOT NULL,
  `cvv` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `food_name`, `price`, `card_number`, `expiry_date`, `cvv`, `username`, `created_on`) VALUES
(1, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:06:05'),
(2, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:08:08'),
(3, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:08:24'),
(4, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:08:42'),
(5, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:08:55'),
(6, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:10:05'),
(7, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:10:19'),
(8, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:10:42'),
(9, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:11:46'),
(10, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:12:35'),
(11, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:14:14'),
(12, 'Hot Pizza', 'â‚¦2,000', '4565767867867876', '354435', '456', '', '2023-10-21 14:14:29'),
(13, 'Patato Chips', 'â‚¦1,200', '4353454543534543', '454354', '353', '', '2023-10-21 15:01:09'),
(14, 'Patato Chips', 'â‚¦1,200', '4353454543534543', '454354', '353', '', '2023-10-21 15:03:25'),
(15, 'Patato Chips', 'â‚¦1,200', '4353454543534543', '454354', '353', '', '2023-10-21 15:05:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `verified` tinyint(4) NOT NULL DEFAULT '0',
  `token` varchar(10) NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(50) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `username`, `email`, `phone`, `gender`, `state`, `password`, `verified`, `token`, `created_on`, `status`) VALUES
(1, 'Yusuf Aminu', 'aaminu', 'aaminu@gmail.com', '', 'Male', 'Katsina', 'e10adc3949ba59abbe56e057f20f883e', 0, '044847', '2023-09-15 11:49:55', 'active'),
(2, 'Rose Emmanuel', 'rose', 'rosemaryfilani25@gmail.com', '', 'Female', 'Jigawa', 'e10adc3949ba59abbe56e057f20f883e', 1, '294707', '2023-09-16 11:55:25', 'active'),
(3, 'Alamin Abubakar Haruna', 'alamin', 'lilwizmin@gmail.com', '09122985153', 'Male', 'Katsina', 'e10adc3949ba59abbe56e057f20f883e', 0, '', '2023-10-21 16:01:10', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drinks`
--
ALTER TABLE `drinks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `foods`
--
ALTER TABLE `foods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `image_url` (`image_url`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `drinks`
--
ALTER TABLE `drinks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `foods`
--
ALTER TABLE `foods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
